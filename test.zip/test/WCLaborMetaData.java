package com.nortech.quote.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "WC_LABOR_METADATA")
public class WCLaborMetaData {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nortechwclabor")
	@SequenceGenerator(name="nortechwclabor", sequenceName = "WC_LABOR_METADATA_SEQ")
	@Column(name = "WC_ID")
	private int id;
	
	@Column(name = "SEQUENCE")
	private String sequence;
	
	@Column(name = "OPERATION")
	private String operation;
	
	@Column(name = "LABOR_STD_HOUR")
	private Float stdHour;
	
}
