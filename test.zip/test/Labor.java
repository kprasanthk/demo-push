package com.nortech.quote.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "LABOR")
public class Labor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nortechlabor")
	@SequenceGenerator(name="nortechlabor", sequenceName = "LABOR_SEQ")
	@Column(name = "LABOR_ID")
	private int id;
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.LAZY)
    @JoinColumn(name="BOM_ID")
	private BillOfMeterial billOfMeterial;
	
	@Column(name = "CREATED_DT")
	private Date createdOn;
	
	@Column(name = "TEMPLATE")
	private String template;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@OneToMany(mappedBy="labor", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<WCLaborBOMItemRollup> bomItemRollUpList;
}
