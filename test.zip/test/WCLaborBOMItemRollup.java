package com.nortech.quote.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "WC_LABOR_BOM_ITM_ROLLUP")
public class WCLaborBOMItemRollup {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wclaborbomitemrollup")
	@SequenceGenerator(name="wclaborbomitemrollup", sequenceName = "WC_LABOR_BOM_ITM_ROLLUP_SEQ")
	@Column(name = "ROLLUP_ID")
	private int id;
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.EAGER)
    @JoinColumn(name="LABOR_ID")
	private Labor labor;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private BillOfMeterialItem bomItem;
	
	@Column(name = "OPERATION")
	private String operation;
	
	@Column(name = "SETUP")
	private Float setup;
	
	@Column(name = "RUN")
	private Float run;
}
