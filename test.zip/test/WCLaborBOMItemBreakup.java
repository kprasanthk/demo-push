package com.nortech.quote.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "WC_LABOR_BOM_ITM_BREAKUP")
public class WCLaborBOMItemBreakup {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wclaborbomitembreakup")
	@SequenceGenerator(name="wclaborbomitembreakup", sequenceName = "WC_LABOR_BOM_ITM_BREAKUP_SEQ")
	@Column(name = "BREAKUP_ID")
	private int id;
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.EAGER)
    @JoinColumn(name="WC_ID")
	private WCLaborMetaData laborMetaData;
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.EAGER)
    @JoinColumn(name="ROLLUP_ID")
	private WCLaborBOMItemRollup laborBOMItemRollup;
	
	@Column(name = "QTY")
	private Integer qty;
	
	@Column(name = "HOURS")
	private Float hours;
	
}
